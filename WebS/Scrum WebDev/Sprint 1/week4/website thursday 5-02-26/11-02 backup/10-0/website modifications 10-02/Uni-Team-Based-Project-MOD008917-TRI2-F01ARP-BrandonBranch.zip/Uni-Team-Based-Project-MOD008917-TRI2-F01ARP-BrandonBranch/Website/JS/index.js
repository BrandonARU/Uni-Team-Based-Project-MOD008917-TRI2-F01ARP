function toggleFab(){
    const fabOptions = document.querySelector('.fabOptions');
    fabOptions.style.display = fabOptions.style.display === 'flex' ? 'none' : 'flex';
}