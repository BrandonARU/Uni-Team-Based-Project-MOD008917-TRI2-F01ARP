This is the repo for the team project, it holds the files for our website and presentation.

To save changes you need to "commit changes"
